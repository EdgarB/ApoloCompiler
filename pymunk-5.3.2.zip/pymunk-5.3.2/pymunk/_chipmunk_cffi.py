from __future__ import absolute_import

from pymunk._chipmunk_cffi_abi import ffi, lib, lib_path 
    